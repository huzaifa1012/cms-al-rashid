import { collection, doc, getDocs, deleteDoc } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-firestore.js";
import { getStorage, ref, deleteObject } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-storage.js";
import { db, storage } from "./firebase.js";

const productContainer = document.getElementById("productContainer");

// Function to render projects
async function renderProjects() {
  try {
    const querySnapshot = await getDocs(collection(db, "projects"));
    productContainer.innerHTML = ""; // Clear previous content

    querySnapshot.forEach((doc) => {
      const data = doc.data();
      const productId = doc.id;

      // Create HTML elements for project
      const productBox = document.createElement("div");
      productBox.classList.add("product-box");

      const image = document.createElement("img");
      image.src = data.images && data.images.length > 0 ? data.images[0] : "placeholder.jpg";
      image.alt = "Product Image";
      productBox.appendChild(image);

      const title = document.createElement("h4");
      title.textContent = data.title.slice(0, 16) + "..";
      productBox.appendChild(title);

      const deleteButton = document.createElement("button");
      deleteButton.textContent = "Delete";
      deleteButton.addEventListener("click", () => deleteProject(productId, data.images));
      productBox.appendChild(deleteButton);

      productContainer.appendChild(productBox);
    });
  } catch (error) {
    console.error("Error rendering projects:", error);
  }
}

async function deleteProject(productId, images) {
  try {
    console.log("Deleting project:", productId);
    console.log("Images to delete:", images);

    // Iterate over the images array and delete each image
    await Promise.all(images.map(async (image, index) => {
      const imageName = image.split('/').pop().split('?')[0]; // Extract image name
      const actualImagePath = image.replace(/%2F/g, '/'); // Replace %2F with /
      console.log(`Deleting image ${index + 1}:`, imageName);

      // Delete the image from Firebase Storage
      const desertRef = ref(storage, actualImagePath);
      await deleteObject(desertRef);
      console.log(`Image ${imageName} deleted successfully`);
    }));

    // Delete Firestore document after all images are deleted
    await deleteDoc(doc(db, "projects", productId));
    console.log('Project deleted successfully');

    // Render projects again after deletion
    await renderProjects();
  } catch (error) {
    console.error("Error deleting project:", error);
  }
}


// Render projects when the page loads
window.addEventListener("load", renderProjects);
