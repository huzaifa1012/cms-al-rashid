import {
  addDoc,
  collection,
  updateDoc
} from "https://www.gstatic.com/firebasejs/9.16.0/firebase-firestore.js";
import {
  ref,
  uploadBytes,
  getDownloadURL,
} from "https://www.gstatic.com/firebasejs/9.16.0/firebase-storage.js";
import { db, storage } from "./firebase.js";

// This is to upload product

let handleAddBTN = document.getElementById("add");
handleAddBTN.addEventListener("click", handleAddProduct);

let prodName = document.getElementById("prod-name");
let prodDetails = document.getElementById("prod-details");
let prodImage = document.getElementById("prod-image");
let spinner = document.getElementById("spinner"); // Reference to the spinner element
let videouri = document.getElementById("videouri"); // Reference to the spinner element

// working with multiple image uploading 
// async function handleAddProduct() {
//   try {
//     // Show the spinner while loading
//     spinner.style.display = "block";

//     const currentDate = new Date();
//     const randomTime = currentDate.getTime();
//     const randomNumber = Math.floor(Math.random() * randomTime);

//     const images = []; // Array to store image download URLs

//     // Iterate through each selected image file
//     for (const imageFile of prodImage.files) {
//       const imageName = randomNumber + imageFile.name;
//       const storageRef = ref(
//         storage,
//         `images/${imageName}`
//       );

//       // Upload image to storage
//       await uploadBytes(storageRef, imageFile);
//       const imageUrl = await getDownloadURL(storageRef);
//       console.log("Image Uploaded", imageUrl);

//       images.push(imageUrl); // Add image URL to the array
//     }

//     // Save the array of image URLs to Firestore
//     const docRef = await addDoc(collection(db, "projects"), {
//       title: prodName.value,
//       description: prodDetails.value,
//       images: images, // Store array of image URLs
//       date: currentDate,
//       id: "", // Leave this field empty for now
//     });
//     const newDocumentId = docRef.id;

//     // Update the document with the ID
//     await updateDoc(docRef, { id: newDocumentId });

//     // Hide the spinner once loading is complete
//     spinner.style.display = "none";
//     alert('Product Added Successfully ');
//     console.log("Data saved");
//   } catch (error) {
//     console.log(error);
//   }
// }

async function handleAddProduct() {

  try {
    // Show the spinner while loading
    spinner.style.display = "block";
    
    if (prodName.value.length < 2 && prodDetails.value.length < 2) {
      alert("Project Name & Description Both are Required");
      spinner.style.display = "none";
      return
    }

    // Check if files are selected
    if (prodImage.files.length === 0) {
      alert("Please select one or more images.");
      spinner.style.display = "none";
    }
    else if (prodImage.files.length > 4) {
      alert("Select Maximum 04 Images ");
      spinner.style.display = "none";

      return
    }


    const currentDate = new Date();

    // Save the array of image URLs to Firestore
    const images = [];
    for (const imageFile of prodImage.files) {
      const uniqueId = generateUniqueId(); // Generate a unique ID for each image
      const imageName = uniqueId + "_" + imageFile.name;
      const storageRef = ref(storage, `images/${imageName}`);

      // Upload image to storage
      await uploadBytes(storageRef, imageFile);
      const imageUrl = await getDownloadURL(storageRef);
      console.log("Image Uploaded", imageUrl);

      images.push(imageUrl); // Add image URL to the array
    }

    // Save data to Firestore
    const docRef = await addDoc(collection(db, "projects"), {
      title: prodName.value,
      description: prodDetails.value,
      images: images, // Store array of image URLs
      date: currentDate,
      videouri: videouri.value,
    });

    // Hide the spinner once loading is complete
    spinner.style.display = "none";
    alert('Product Added Successfully ');
    console.log("Data saved with ID:", docRef.id);
  } catch (error) {
    console.error("Error adding product:", error);
    alert("An error occurred while adding the product. Please try again later.");
  }
}

// Function to generate a unique ID
function generateUniqueId() {
  return new Date().getTime().toString(36) + Math.random().toString(36).substr(2, 5);
}

