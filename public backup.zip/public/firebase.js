import { initializeApp } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-analytics.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-storage.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDZOGRBpMFLVdBiIpoFiOpNQwYQffXlG24",
  authDomain: "alr-ashid.firebaseapp.com",
  projectId: "alr-ashid",
  storageBucket: "alr-ashid.appspot.com",
  messagingSenderId: "420340164444",
  appId: "1:420340164444:web:fba42aebb7ea95febbc399"
};


export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);
